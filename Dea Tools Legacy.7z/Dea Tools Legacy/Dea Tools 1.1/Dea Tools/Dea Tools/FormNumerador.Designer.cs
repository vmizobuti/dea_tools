﻿namespace Dea_Tools
{
    partial class FormNumerador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNumerador));
            this.apenasPares = new System.Windows.Forms.CheckBox();
            this.apenasImpares = new System.Windows.Forms.CheckBox();
            this.botaoIniciar = new System.Windows.Forms.Button();
            this.numInicio = new System.Windows.Forms.TextBox();
            this.lblInicio = new System.Windows.Forms.Label();
            this.lblFinal = new System.Windows.Forms.Label();
            this.numFinal = new System.Windows.Forms.TextBox();
            this.lblPrefixo = new System.Windows.Forms.Label();
            this.numPrefixo = new System.Windows.Forms.TextBox();
            this.botaoCancelar = new System.Windows.Forms.Button();
            this.lblSufixo = new System.Windows.Forms.Label();
            this.numSufixo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.titOpcionais = new System.Windows.Forms.Label();
            this.titParam = new System.Windows.Forms.Label();
            this.checkZeros = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // apenasPares
            // 
            this.apenasPares.AutoSize = true;
            this.apenasPares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apenasPares.Location = new System.Drawing.Point(12, 184);
            this.apenasPares.Name = "apenasPares";
            this.apenasPares.Size = new System.Drawing.Size(92, 17);
            this.apenasPares.TabIndex = 0;
            this.apenasPares.Text = "Apenas Pares";
            this.apenasPares.UseVisualStyleBackColor = true;
            this.apenasPares.CheckedChanged += new System.EventHandler(this.apenasPares_CheckedChanged);
            // 
            // apenasImpares
            // 
            this.apenasImpares.AutoSize = true;
            this.apenasImpares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.apenasImpares.Location = new System.Drawing.Point(12, 207);
            this.apenasImpares.Name = "apenasImpares";
            this.apenasImpares.Size = new System.Drawing.Size(105, 17);
            this.apenasImpares.TabIndex = 1;
            this.apenasImpares.Text = "Apenas Ímpares ";
            this.apenasImpares.UseVisualStyleBackColor = true;
            this.apenasImpares.CheckedChanged += new System.EventHandler(this.apenasImpares_CheckedChanged);
            // 
            // botaoIniciar
            // 
            this.botaoIniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botaoIniciar.Location = new System.Drawing.Point(76, 272);
            this.botaoIniciar.Name = "botaoIniciar";
            this.botaoIniciar.Size = new System.Drawing.Size(95, 23);
            this.botaoIniciar.TabIndex = 2;
            this.botaoIniciar.Text = "Iniciar";
            this.botaoIniciar.UseVisualStyleBackColor = true;
            this.botaoIniciar.Click += new System.EventHandler(this.botaoIniciar_Click);
            // 
            // numInicio
            // 
            this.numInicio.Location = new System.Drawing.Point(181, 38);
            this.numInicio.Name = "numInicio";
            this.numInicio.Size = new System.Drawing.Size(91, 20);
            this.numInicio.TabIndex = 3;
            this.numInicio.TextChanged += new System.EventHandler(this.numInicio_TextChanged);
            // 
            // lblInicio
            // 
            this.lblInicio.AutoSize = true;
            this.lblInicio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInicio.Location = new System.Drawing.Point(12, 41);
            this.lblInicio.Name = "lblInicio";
            this.lblInicio.Size = new System.Drawing.Size(89, 13);
            this.lblInicio.TabIndex = 4;
            this.lblInicio.Text = "Número de Início";
            // 
            // lblFinal
            // 
            this.lblFinal.AutoSize = true;
            this.lblFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinal.Location = new System.Drawing.Point(12, 67);
            this.lblFinal.Name = "lblFinal";
            this.lblFinal.Size = new System.Drawing.Size(100, 13);
            this.lblFinal.TabIndex = 6;
            this.lblFinal.Text = "Número de Término";
            // 
            // numFinal
            // 
            this.numFinal.Location = new System.Drawing.Point(181, 64);
            this.numFinal.Name = "numFinal";
            this.numFinal.Size = new System.Drawing.Size(91, 20);
            this.numFinal.TabIndex = 5;
            this.numFinal.TextChanged += new System.EventHandler(this.numFinal_TextChanged);
            // 
            // lblPrefixo
            // 
            this.lblPrefixo.AutoSize = true;
            this.lblPrefixo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrefixo.Location = new System.Drawing.Point(12, 133);
            this.lblPrefixo.Name = "lblPrefixo";
            this.lblPrefixo.Size = new System.Drawing.Size(39, 13);
            this.lblPrefixo.TabIndex = 8;
            this.lblPrefixo.Text = "Prefixo";
            // 
            // numPrefixo
            // 
            this.numPrefixo.Location = new System.Drawing.Point(181, 130);
            this.numPrefixo.Name = "numPrefixo";
            this.numPrefixo.Size = new System.Drawing.Size(91, 20);
            this.numPrefixo.TabIndex = 7;
            this.numPrefixo.TextChanged += new System.EventHandler(this.numPrefixo_TextChanged);
            // 
            // botaoCancelar
            // 
            this.botaoCancelar.Location = new System.Drawing.Point(177, 272);
            this.botaoCancelar.Name = "botaoCancelar";
            this.botaoCancelar.Size = new System.Drawing.Size(95, 23);
            this.botaoCancelar.TabIndex = 9;
            this.botaoCancelar.Text = "Cancelar";
            this.botaoCancelar.UseVisualStyleBackColor = true;
            this.botaoCancelar.Click += new System.EventHandler(this.botaoCancelar_Click);
            // 
            // lblSufixo
            // 
            this.lblSufixo.AutoSize = true;
            this.lblSufixo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSufixo.Location = new System.Drawing.Point(12, 159);
            this.lblSufixo.Name = "lblSufixo";
            this.lblSufixo.Size = new System.Drawing.Size(36, 13);
            this.lblSufixo.TabIndex = 11;
            this.lblSufixo.Text = "Sufixo";
            // 
            // numSufixo
            // 
            this.numSufixo.Location = new System.Drawing.Point(181, 156);
            this.numSufixo.Name = "numSufixo";
            this.numSufixo.Size = new System.Drawing.Size(91, 20);
            this.numSufixo.TabIndex = 10;
            this.numSufixo.TextChanged += new System.EventHandler(this.numSufixo_TextChanged);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Cursor = System.Windows.Forms.Cursors.No;
            this.label2.Location = new System.Drawing.Point(-16, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(316, 164);
            this.label2.TabIndex = 13;
            // 
            // titOpcionais
            // 
            this.titOpcionais.AutoSize = true;
            this.titOpcionais.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.titOpcionais.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titOpcionais.Location = new System.Drawing.Point(12, 106);
            this.titOpcionais.Name = "titOpcionais";
            this.titOpcionais.Size = new System.Drawing.Size(54, 13);
            this.titOpcionais.TabIndex = 14;
            this.titOpcionais.Text = "Opcionais";
            // 
            // titParam
            // 
            this.titParam.AutoSize = true;
            this.titParam.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.titParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titParam.Location = new System.Drawing.Point(12, 13);
            this.titParam.Name = "titParam";
            this.titParam.Size = new System.Drawing.Size(60, 13);
            this.titParam.TabIndex = 15;
            this.titParam.Text = "Parâmetros";
            // 
            // checkZeros
            // 
            this.checkZeros.AutoSize = true;
            this.checkZeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkZeros.Location = new System.Drawing.Point(12, 230);
            this.checkZeros.Name = "checkZeros";
            this.checkZeros.Size = new System.Drawing.Size(163, 17);
            this.checkZeros.TabIndex = 16;
            this.checkZeros.Text = "Zeros no Início (ex.: 01, 001)";
            this.checkZeros.UseVisualStyleBackColor = true;
            this.checkZeros.CheckedChanged += new System.EventHandler(this.checkZeros_CheckedChanged);
            // 
            // FormNumerador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.ClientSize = new System.Drawing.Size(284, 306);
            this.Controls.Add(this.checkZeros);
            this.Controls.Add(this.titParam);
            this.Controls.Add(this.titOpcionais);
            this.Controls.Add(this.lblSufixo);
            this.Controls.Add(this.numSufixo);
            this.Controls.Add(this.botaoCancelar);
            this.Controls.Add(this.lblPrefixo);
            this.Controls.Add(this.numPrefixo);
            this.Controls.Add(this.lblFinal);
            this.Controls.Add(this.numFinal);
            this.Controls.Add(this.lblInicio);
            this.Controls.Add(this.numInicio);
            this.Controls.Add(this.botaoIniciar);
            this.Controls.Add(this.apenasImpares);
            this.Controls.Add(this.apenasPares);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormNumerador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dea Tools 1.1 - Numerador";
            this.Load += new System.EventHandler(this.FormNumerador_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox apenasPares;
        private System.Windows.Forms.CheckBox apenasImpares;
        private System.Windows.Forms.Button botaoIniciar;
        private System.Windows.Forms.TextBox numInicio;
        private System.Windows.Forms.Label lblInicio;
        private System.Windows.Forms.Label lblFinal;
        private System.Windows.Forms.TextBox numFinal;
        private System.Windows.Forms.Label lblPrefixo;
        private System.Windows.Forms.TextBox numPrefixo;
        private System.Windows.Forms.Button botaoCancelar;
        private System.Windows.Forms.Label lblSufixo;
        private System.Windows.Forms.TextBox numSufixo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label titOpcionais;
        private System.Windows.Forms.Label titParam;
        private System.Windows.Forms.CheckBox checkZeros;
    }
}