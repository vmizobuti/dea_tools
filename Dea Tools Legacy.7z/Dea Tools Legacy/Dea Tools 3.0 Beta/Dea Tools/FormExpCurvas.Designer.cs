﻿namespace Dea_Tools
{
    partial class FormExpCurvas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormExpCurvas));
            this.titParam = new System.Windows.Forms.Label();
            this.ativaSelecPasta = new System.Windows.Forms.Button();
            this.caminhoPasta = new System.Windows.Forms.TextBox();
            this.selecPasta = new System.Windows.Forms.FolderBrowserDialog();
            this.botaoCancelar = new System.Windows.Forms.Button();
            this.botaoIniciar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titParam
            // 
            this.titParam.AutoSize = true;
            this.titParam.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.titParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titParam.Location = new System.Drawing.Point(12, 13);
            this.titParam.Name = "titParam";
            this.titParam.Size = new System.Drawing.Size(57, 13);
            this.titParam.TabIndex = 16;
            this.titParam.Text = "Salvar em:";
            // 
            // ativaSelecPasta
            // 
            this.ativaSelecPasta.Location = new System.Drawing.Point(342, 12);
            this.ativaSelecPasta.Name = "ativaSelecPasta";
            this.ativaSelecPasta.Size = new System.Drawing.Size(30, 20);
            this.ativaSelecPasta.TabIndex = 17;
            this.ativaSelecPasta.Text = "...";
            this.ativaSelecPasta.UseVisualStyleBackColor = true;
            this.ativaSelecPasta.Click += new System.EventHandler(this.ativaSelecPasta_Click);
            // 
            // caminhoPasta
            // 
            this.caminhoPasta.Location = new System.Drawing.Point(75, 13);
            this.caminhoPasta.Name = "caminhoPasta";
            this.caminhoPasta.Size = new System.Drawing.Size(261, 20);
            this.caminhoPasta.TabIndex = 18;
            this.caminhoPasta.TextChanged += new System.EventHandler(this.caminhoPasta_TextChanged);
            // 
            // botaoCancelar
            // 
            this.botaoCancelar.Location = new System.Drawing.Point(277, 56);
            this.botaoCancelar.Name = "botaoCancelar";
            this.botaoCancelar.Size = new System.Drawing.Size(95, 23);
            this.botaoCancelar.TabIndex = 20;
            this.botaoCancelar.Text = "Cancelar";
            this.botaoCancelar.UseVisualStyleBackColor = true;
            this.botaoCancelar.Click += new System.EventHandler(this.botaoCancelar_Click);
            // 
            // botaoIniciar
            // 
            this.botaoIniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botaoIniciar.Location = new System.Drawing.Point(176, 56);
            this.botaoIniciar.Name = "botaoIniciar";
            this.botaoIniciar.Size = new System.Drawing.Size(95, 23);
            this.botaoIniciar.TabIndex = 19;
            this.botaoIniciar.Text = "Iniciar";
            this.botaoIniciar.UseVisualStyleBackColor = true;
            this.botaoIniciar.Click += new System.EventHandler(this.botaoIniciar_Click);
            // 
            // FormExpCurvas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(384, 91);
            this.Controls.Add(this.botaoCancelar);
            this.Controls.Add(this.botaoIniciar);
            this.Controls.Add(this.caminhoPasta);
            this.Controls.Add(this.ativaSelecPasta);
            this.Controls.Add(this.titParam);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormExpCurvas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dea Tools 3.0 BETA - Exportar em Curvas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titParam;
        private System.Windows.Forms.Button ativaSelecPasta;
        private System.Windows.Forms.TextBox caminhoPasta;
        private System.Windows.Forms.FolderBrowserDialog selecPasta;
        private System.Windows.Forms.Button botaoCancelar;
        private System.Windows.Forms.Button botaoIniciar;
    }
}