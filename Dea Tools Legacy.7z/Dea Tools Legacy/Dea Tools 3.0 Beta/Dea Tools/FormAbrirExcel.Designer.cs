﻿namespace Dea_Tools
{
    partial class FormAbrirExcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAbrirExcel));
            this.titParam = new System.Windows.Forms.Label();
            this.ativaSelecExcel = new System.Windows.Forms.Button();
            this.caminhoExcel = new System.Windows.Forms.TextBox();
            this.selecExcel = new System.Windows.Forms.OpenFileDialog();
            this.botaoCancelar = new System.Windows.Forms.Button();
            this.botaoIniciar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titParam
            // 
            this.titParam.AutoSize = true;
            this.titParam.Cursor = System.Windows.Forms.Cursors.SizeNESW;
            this.titParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titParam.Location = new System.Drawing.Point(12, 13);
            this.titParam.Name = "titParam";
            this.titParam.Size = new System.Drawing.Size(46, 13);
            this.titParam.TabIndex = 16;
            this.titParam.Text = "Arquivo:";
            // 
            // ativaSelecExcel
            // 
            this.ativaSelecExcel.Location = new System.Drawing.Point(342, 12);
            this.ativaSelecExcel.Name = "ativaSelecExcel";
            this.ativaSelecExcel.Size = new System.Drawing.Size(30, 20);
            this.ativaSelecExcel.TabIndex = 17;
            this.ativaSelecExcel.Text = "...";
            this.ativaSelecExcel.UseVisualStyleBackColor = true;
            this.ativaSelecExcel.Click += new System.EventHandler(this.ativaSelecExcel_Click);
            // 
            // caminhoExcel
            // 
            this.caminhoExcel.Location = new System.Drawing.Point(75, 13);
            this.caminhoExcel.Name = "caminhoExcel";
            this.caminhoExcel.Size = new System.Drawing.Size(261, 20);
            this.caminhoExcel.TabIndex = 18;
            this.caminhoExcel.TextChanged += new System.EventHandler(this.caminhoExcel_TextChanged);
            // 
            // botaoCancelar
            // 
            this.botaoCancelar.Location = new System.Drawing.Point(277, 56);
            this.botaoCancelar.Name = "botaoCancelar";
            this.botaoCancelar.Size = new System.Drawing.Size(95, 23);
            this.botaoCancelar.TabIndex = 20;
            this.botaoCancelar.Text = "Cancelar";
            this.botaoCancelar.UseVisualStyleBackColor = true;
            this.botaoCancelar.Click += new System.EventHandler(this.botaoCancelar_Click);
            // 
            // botaoIniciar
            // 
            this.botaoIniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botaoIniciar.Location = new System.Drawing.Point(176, 56);
            this.botaoIniciar.Name = "botaoIniciar";
            this.botaoIniciar.Size = new System.Drawing.Size(95, 23);
            this.botaoIniciar.TabIndex = 19;
            this.botaoIniciar.Text = "Iniciar";
            this.botaoIniciar.UseVisualStyleBackColor = true;
            this.botaoIniciar.Click += new System.EventHandler(this.botaoIniciar_Click);
            // 
            // FormAbrirExcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(384, 91);
            this.Controls.Add(this.botaoCancelar);
            this.Controls.Add(this.botaoIniciar);
            this.Controls.Add(this.caminhoExcel);
            this.Controls.Add(this.ativaSelecExcel);
            this.Controls.Add(this.titParam);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAbrirExcel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dea Tools 3.0 BETA - Excel para Placas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titParam;
        private System.Windows.Forms.Button ativaSelecExcel;
        private System.Windows.Forms.TextBox caminhoExcel;
        private System.Windows.Forms.OpenFileDialog selecExcel;
        private System.Windows.Forms.Button botaoCancelar;
        private System.Windows.Forms.Button botaoIniciar;
    }
}