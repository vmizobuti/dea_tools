﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace Dea_Tools
{
    public partial class FormExpCurvas : Form
    {
        public FormExpCurvas()
        {
            InitializeComponent();
        }

        // Declara as variáveis utilizadas no formulário
        public string caminhoPastaTxt { get; set; }

        private void ativaSelecPasta_Click(object sender, EventArgs e)
        {
            if (selecPasta.ShowDialog() == DialogResult.OK)
            {
                caminhoPasta.Text = selecPasta.SelectedPath;
            }
        }

        private void caminhoPasta_TextChanged(object sender, EventArgs e)
        {
            caminhoPastaTxt = caminhoPasta.Text;
        }

        private void botaoCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void botaoIniciar_Click(object sender, EventArgs e)
        {
            // Verifica condições de entradas para iniciar o código de numeração
            if (caminhoPasta.Text == "")
            {
                System.Windows.MessageBox.Show("Insira uma pasta para salvar os arquivos de produção.", "Atenção!");
            }
            // Inicia os valores para o código fonte
            else
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}
