﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.VisualBasic;
using corel = Corel.Interop.VGCore;

namespace Dea_Tools
{
    public partial class DockerUI : UserControl
    {
        private corel.Application corelApp;
        private Styles.StylesController stylesController;
        public DockerUI(object app)
        {
            InitializeComponent();
            try
            {
                this.corelApp = app as corel.Application;
                stylesController = new Styles.StylesController(this.Resources, this.corelApp);
            }
            catch
            {
                global::System.Windows.MessageBox.Show("VGCore Erro");
            }

        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            stylesController.LoadThemeFromPreference();
        }


        // Numerador Automático - Dea! Design
        private void numAutomatico(object sender, RoutedEventArgs e)
        {
            // Verifica se o usuário está selecionando objetos
            if (corelApp.ActiveSelectionRange.Count == 0)
            {
                System.Windows.MessageBox.Show("Selecione um objeto e/ou grupo para iniciar a numeração, já contendo um texto de base formatado.", "Atenção!");
            }
            else
            {
                // Verifica se os objetos selecionados incluem textos
                if (corelApp.ActiveSelection.Shapes.FindShapes(Type: corel.cdrShapeType.cdrTextShape).Count != 1)
                {
                    System.Windows.MessageBox.Show("Selecione um objeto/grupo que inclua um (apenas 1) texto para numeração.", "Atenção!");
                }
                else
                {
                    // Inicia o formulário para coleta das variáveis
                    FormNumerador formVal = new FormNumerador();
                    
                    System.Windows.Forms.Application.Run(formVal);

                    // Inicia a ação do formulário após o usuário apertar 'Iniciar'
                    if (formVal.DialogResult == System.Windows.Forms.DialogResult.OK)
                    {
                        // Declara as variáveis de Início e Término da contagem
                        int numInicial = formVal.frmInicial;
                        int numFinal = formVal.frmFinal;

                        int rangeNum = numFinal - numInicial;

                        // Declara o contador de placas, para posicionamento
                        int contagem = 0;

                        // Copia a seleção de objetos e altera a numeração e o posicionamento da cópia
                        for (int i = 0; i < rangeNum + 1; i++)
                        {
                            // Caso Apenas Pares tenha sido selecionado, pula a contagem ímpar
                            if (formVal.frmPares == true && ((numInicial + i) % 2) != 0)
                            {
                                continue;
                            }

                            // Caso Apenas Ímpares tenha sido selecionado, pula a contagem par
                            if (formVal.frmImpares == true && ((numInicial + i) % 2) == 0)
                            {
                                continue;
                            }

                            // Declara as variáveis de posicionamento da nova cópia
                            double offX = 0.0;
                            double offY = 0.0;

                            // Declara as variáveis de substituição do texto do grupo selecionado
                            string novoTexto = "";
                            string txtExistente = corelApp.ActiveSelection.Shapes.FindShape(Type: corel.cdrShapeType.cdrTextShape).Text.Story.Text;

                            // Caso tenha sido definido um prefixo, este é adicionado ao texto para substituição
                            if (formVal.frmPrefixo != "")
                            {
                                novoTexto += formVal.frmPrefixo;
                            }

                            // Adiciona o número '0' ao texto para substituição de acordo com o total de números da contagem
                            if (numFinal < 100)
                            {
                                if (i + numInicial < 10)
                                {
                                    novoTexto += "0" + $"{numInicial + i}";
                                }
                                else
                                {
                                    novoTexto += $"{numInicial + i}";
                                }
                            }
                            else
                            {
                                if (i + numInicial < 10)
                                {
                                    novoTexto += "00" + $"{numInicial + i}";
                                }
                                else if (i + numInicial < 100)
                                {
                                    novoTexto += "0" + $"{numInicial + i}";
                                }
                                else
                                {
                                    novoTexto += $"{numInicial + i}";
                                }
                            }

                            // Caso tenha sido definido um sufixo, este é adicionado ao texto para substituição
                            if (formVal.frmSufixo != "")
                            {
                                novoTexto += formVal.frmSufixo;
                            }

                            // Define os valores para posicionamento da nova cópia
                            corelApp.ActiveSelection.GetSize(out offX, out offY);

                            // Substitui o texto da seleção de acordo com o texto definido anteriormente
                            corelApp.ActiveSelection.Shapes.FindShape(Type: corel.cdrShapeType.cdrTextShape).Text.Replace(OldText: txtExistente,
                                                                                                                          NewText: novoTexto,
                                                                                                                          CaseSensitive: true);
                            // Duplica a seleção de acordo com o posicionamento definido anteriormente, multiplicado por 1.5
                            corelApp.ActiveSelection.Duplicate(contagem * offX * 1.5);

                            contagem += 1;
                        }

                        // Remove a seleção inicial para evitar a existência de sobreposição de objetos
                        corelApp.ActiveSelection.Delete();
                    }
                }
            }
        }
    }
}
