﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Dea_Tools
{
    public partial class FormNumerador : Form
    {
        public FormNumerador()
        {
            InitializeComponent();
        }

        // Declara as variáveis utilizadas no formulário
        public int frmInicial { get; set; }
        public int frmFinal { get; set; }
        public string frmPrefixo { get; set; }
        public string frmSufixo { get; set; }
        public Boolean frmPares { get; set; }
        public Boolean frmImpares { get; set; }
        public Boolean frmZeros { get; set; }

        // Aloca os valores nas variáveis
        private void numInicio_TextChanged(object sender, EventArgs e)
        {
            int outTemp = 0;

            if (!Int32.TryParse(numInicio.Text, out outTemp))
            {
                System.Windows.MessageBox.Show("Não insira letras no número de ínicio.", "Atenção!");
            }
            else
            {
                frmInicial = Int32.Parse(numInicio.Text);
            }
        }

        private void numFinal_TextChanged(object sender, EventArgs e)
        {
            int outTemp = 0;

            if (!Int32.TryParse(numFinal.Text, out outTemp))
            {
                System.Windows.MessageBox.Show("Não insira letras no número de término.", "Atenção!");
            }
            else
            {
                frmFinal = Int32.Parse(numFinal.Text);
            }        
        }

        private void numPrefixo_TextChanged(object sender, EventArgs e)
        {
            frmPrefixo = numPrefixo.Text;
        }

        private void numSufixo_TextChanged(object sender, EventArgs e)
        {
            frmSufixo = numSufixo.Text;
        }

        private void apenasPares_CheckedChanged(object sender, EventArgs e)
        {
            frmPares = apenasPares.Checked;
        }

        private void apenasImpares_CheckedChanged(object sender, EventArgs e)
        {
            frmImpares = apenasImpares.Checked;
        }

        private void checkZeros_CheckedChanged(object sender, EventArgs e)
        {
            frmZeros = checkZeros.Checked;
        }

        // Cancela a ação do código fonte
        private void botaoCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // Repassa os valores do formulário para o código fonte
        private void botaoIniciar_Click(object sender, EventArgs e)
        {
            // Verifica condições de entradas para iniciar o código de numeração
            if (numInicio.Text == "")
            {
                System.Windows.MessageBox.Show("Insira um número de início.", "Atenção!");
            }
            else if (numFinal.Text == "")
            {
                System.Windows.MessageBox.Show("Insira um número de término.", "Atenção!");
            }
            else if (apenasPares.Checked & apenasImpares.Checked)
            {
                System.Windows.MessageBox.Show("Selecione apenas uma ou nenhuma das caixas de seleção de Pares e Ímpares.", "Atenção!");
            }
            // Inicia os valores para o código fonte
            else
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }        
        }

        private void FormNumerador_Load(object sender, EventArgs e)
        {

        }
    }
}
